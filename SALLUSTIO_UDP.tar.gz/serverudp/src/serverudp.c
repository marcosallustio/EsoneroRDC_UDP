/*
 ============================================================================
 Name        : serverchat.c
 Author      : marcosallustio
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<stdio.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include <stdbool.h>
#include <netdb.h>
#include <stdlib.h>
#include "protocol.h"

float add(float, float);
float sub(float, float);
float mult(float, float);
float division(float, float);

void error(const char *msg) {
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[]) {
	struct sockaddr_in client, server;
	int s, portno;
	socklen_t n;
	const char *ip = "127.0.0.1";
	struct in_addr addr;
	struct hostent *remoteHost;
	addr.s_addr = inet_addr(ip);
	inet_aton(ip, &addr);
	remoteHost = gethostbyaddr(&addr, sizeof(addr), AF_INET);
	struct in_addr *ina = (struct in_addr*) remoteHost->h_addr_list[0];

	if (argc > 1) {
		portno = atoi(argv[1]);
	} else {
		portno = PROTOPORT;
	}

	//creation of the socket
	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		error("Error opening socket");
	}

	//construction of the server address
	server.sin_family = AF_INET;
	server.sin_port = htons(portno);
	server.sin_addr.s_addr = INADDR_ANY;

	//bind of the socket
	if (bind(s, (struct sockaddr*) &server, sizeof(server)) < 0) {
		printf("bind()failed");
	}
	printf("\nServer ready,waiting for client....\n");

	n = sizeof(client);
	struct t_op op;
	float res = 0;
	while (1) {
		//receiving client input
		recvfrom(s, (&op.choice), sizeof(op.choice), 0,
				(struct sockaddr*) &client, &n);
		recvfrom(s, (&op.num1), sizeof(op.num1), 0, (struct sockaddr*) &client,
				&n);
		recvfrom(s, (&op.num2), sizeof(op.num2), 0, (struct sockaddr*) &client,
				&n);

		char *type_op;
		//creation of the operation log
		if (op.choice == 1) {
			type_op = "+";
			printf("Requested operation %s %d %d", type_op, op.num1, op.num2);
			printf(" from client  %s", remoteHost->h_name);
			printf(",ip %s\n", inet_ntoa(*ina));
		} else if (op.choice == 2) {
			type_op = "-";
			printf("Requested operation %s %d %d", type_op, op.num1, op.num2);
			printf(" from client  %s", remoteHost->h_name);
			printf(",ip %s\n", inet_ntoa(*ina));
		} else if (op.choice == 3) {
			type_op = "*";
			printf("Requested operation %s %d %d", type_op, op.num1, op.num2);
			printf(" from client  %s", remoteHost->h_name);
			printf(",ip %s\n", inet_ntoa(*ina));
		} else if (op.choice == 4) {
			type_op = "/";
			printf("Requested operation %s %d %d", type_op, op.num1, op.num2);
			printf(" from client  %s", remoteHost->h_name);
			printf(",ip %s\n", inet_ntoa(*ina));

		} else if (op.choice == 5) {
			printf("Client disconnection...\n");

		}

		//construction of the result
		switch (op.choice) {
		case 1:
			res = add(op.num1, op.num2);
			break;

		case 2:
			res = sub(op.num1, op.num2);
			break;

		case 3:
			res = mult(op.num1, op.num2);
			break;

		case 4:
			res = division(op.num1, op.num2);
			if (op.num2 == 0) {
				res = 0;
			}
			break;

		case 5:
			printf("\nServer ready,waiting for client....\n");
			break;

		}
		//sending the result to the client
		sendto(s, (void*) &res, sizeof(op), 0, (struct sockaddr*) &client, n);

	}
	return 0;
}
