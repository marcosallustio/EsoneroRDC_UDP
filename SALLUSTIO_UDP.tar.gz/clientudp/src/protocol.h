/*
 * protocol.h
 *
 *  Created on: 15 dic 2021
 *      Author: marco
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTOPORT 9898
#define ADDRESS "localhost"

typedef struct t_op {
	int num1,num2;
	int choice;
	float res;
}t_op;

float add(float a, float b)
{
	return a+b;
}

float sub(float a, float b)
{
	return a-b;
}

float mult(float a, float b)
{
	return a*b;
}

float division(float a, float b)
{
	if(b==0)
	{
		printf("Impossible to divide by zero\n");
	}
	return a/b;
}

#endif /* PROTOCOL_H_ */

