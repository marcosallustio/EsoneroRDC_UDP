/*
 ============================================================================
 Name        : clientchat.c
 Author      : marcosallustio
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<netdb.h>
#include <unistd.h>
#include<string.h>
#include<strings.h>
#include <arpa/inet.h>
#include "protocol.h"

void error(const char *msg) {
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[]) {
	int portno;
	int errorop = 0;
	struct sockaddr_in server;
	struct in_addr addr;
	struct hostent *servername;
	struct hostent *remoteHost;
	const char *ip = "127.0.0.1";
	int s, n;
	inet_aton(ip, &addr);
	char *token1;

	if (argc < 2) {
		portno = PROTOPORT;
		servername = gethostbyname(ADDRESS);
	} else {

		char *separator = ":";
		strtok_r(argv[1], separator, &token1);
		servername = gethostbyname(argv[1]);
		if (servername == NULL) {
			fprintf(stderr, "Error, no such host");
			exit(1);
		}
		portno = atoi(token1);

	}

	//creation of the socket
	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		error("Error opening socket");
	}

	//construction of the server address
	server.sin_family = AF_INET;
	server.sin_port = htons(portno);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	printf("\nClient ready....\n");
	n = sizeof(server);

	struct t_op op;
	float res = 0;
	while (1) {
		//entering the data to be sent
		Q: printf(
				"\nInsert the operation in the format [Type of operation] [Number] [Number]\n");
		printf(
				"Indicate the type of operation with the corresponding number:\n");
		printf(
				"To close the client enter the number 5 followed equally by both numbers\n");
		printf("1)+\n2)-\n3)*\n4)/\n5)=\n");
		printf("\nClient:");

		scanf("%d %d %d", &op.choice, &op.num1, &op.num2);
		fflush(stdin);
		if (op.choice > 5) {
			errorop = 1;
		} else {
			errorop = 0;
		}
		if (errorop == 1) {
			printf("Enter valid operator\n");
			goto Q;
		}

		//sending the data to the server
		sendto(s, &op.choice, sizeof(op), 0, (struct sockaddr*) &server, n);
		sendto(s, &op.num1, sizeof(op), 0, (struct sockaddr*) &server, n);
		sendto(s, &op.num2, sizeof(op), 0, (struct sockaddr*) &server, n);

		if (op.choice == 5) {
			printf("Client disconnection... \n");
			close(s);
			return 0;
		}

		struct in_addr *ina = (struct in_addr*) servername->h_addr_list[0];

		//receiving result from server
		recvfrom(s, (void*) &res, sizeof(res), 0, NULL, NULL);
		char *type_op;
		if (op.choice == 1) {
			type_op = "+";
		} else if (op.choice == 2) {
			type_op = "-";

		} else if (op.choice == 3) {
			type_op = "*";

		} else if (op.choice == 4) {
			type_op = "/";
		}

		remoteHost = gethostbyaddr((char*) &addr, sizeof(addr), AF_INET);
		printf("Received result from server %s", servername->h_name);
		printf(",ip  %s", inet_ntoa(*ina));
		printf(": %d%s%d", op.num1, type_op, op.num2);
		printf("=%.2f\n", res);

	}

}

